library(vars)



example(Acoef)
example(arch.test)
example(Bcoef)
example(BQ)
example(causality)
example(fanchart)
example(fevd)
example(irf)
example(normality.test)
example(Phi)
example(Psi)
example(restrict)
example(roots)
example(serial.test)
example(stability)
example(SVAR)
example(SVEC)
example(VAR)
example(VARselect)
example(vec2var)


