print.varprd <- function(x, ...){
  print(x$fcst, ...)
  invisible(x)
}
