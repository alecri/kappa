"plot.vec2var" <-
function(x, ...){
  plot.varest(x, ...)
}
