###
### R routines for the R package mvmeta (c) Antonio Gasparrini 2012-2014
#
blup <-
function (object, ...) UseMethod("blup")
