#' @title Data for timelineS function example in timelineS package
#' @description Events and dates of Michael Jackson's life
#' @name mj_life
#' @docType data
#' @format dataframe of events(character) and dates(date)
NULL
