#ifndef QAP_DECODE_H__
#define QAP_DECODE_H__

/* this is a compatibility header so we can re-use Rserve/src/qap_decode.c as-is */
#include "qap.h"

#endif
