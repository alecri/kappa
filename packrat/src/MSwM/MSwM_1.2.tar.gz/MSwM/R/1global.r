
setGeneric("msmFit",function(object,k,sw,p,data,family,control){standardGeneric("msmFit")})

setGeneric("plotProb",function(x,which){standardGeneric("plotProb")})

setGeneric("plotReg",function(x,expl,regime=1){standardGeneric("plotReg")})

setGeneric("plotDiag",function(x,regime,which){standardGeneric("plotDiag")})

setGeneric("msmResid",function(object,regime){standardGeneric("msmResid")})

setGeneric("msmFilter",function(object){standardGeneric("msmFilter")})

setGeneric("msmSmooth",function(object){standardGeneric("msmSmooth")})

setGeneric("maximEM",function(object,dades){standardGeneric("maximEM")})

setGeneric("iteraEM",function(object,dades,control){standardGeneric("iteraEM")})

setGeneric("em",function(object,control){standardGeneric("em")})

setGeneric("hessian",function(object){standardGeneric("hessian")})

