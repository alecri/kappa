library(testthat)
library(lintr)

test_check("lintr")
