#ifndef MAPPLY_H
#define MAPPLY_H

#include "mapply_4.h"
#include "mapply_5.h"

#endif
