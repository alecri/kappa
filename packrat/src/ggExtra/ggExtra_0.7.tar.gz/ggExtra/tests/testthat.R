library(testthat)
library(ggExtra)

test_check("ggExtra")