
# 2.1.1

* Fix R download counts if a day is missing data (e.g. 2015-08-23).

# 2.1.0

* Query downloads of R: `cran_downloads("R")`.

# 2.0.0

* First release on CRAN.
* Queries return data frames.

# 1.0.0

* First public release.
