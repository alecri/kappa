library(testthat)

test_check('ggfortify')
