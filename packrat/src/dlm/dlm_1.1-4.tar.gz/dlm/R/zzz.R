
.onUnload <- function(libpath) {
    library.dynam.unload("dlm", libpath)
}
