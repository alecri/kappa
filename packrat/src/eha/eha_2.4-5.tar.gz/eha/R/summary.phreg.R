summary.phreg <- function(object, ...) print(object)
