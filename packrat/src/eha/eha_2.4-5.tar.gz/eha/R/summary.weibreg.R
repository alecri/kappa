summary.weibreg <- function(object, ...) print(object)
