summary.aftreg <- function(object, ...) print(object)
