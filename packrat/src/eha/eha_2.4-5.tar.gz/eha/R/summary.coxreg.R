summary.coxreg <- function(object, ...) print(object)
