#summarise <- function (...) {
#	.Deprecated("summarise", package="vcdExtra")
#	LRstats(...)
#}
#
