baujat <- function(x, ...)
   UseMethod("baujat")
