leave1out <- function(x, ...)
   UseMethod("leave1out")
