radial <- galbraith <- function(x, ...)
   UseMethod("radial")
