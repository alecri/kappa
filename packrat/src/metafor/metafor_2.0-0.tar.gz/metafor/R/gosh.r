gosh <- function(x, ...)
   UseMethod("gosh")
