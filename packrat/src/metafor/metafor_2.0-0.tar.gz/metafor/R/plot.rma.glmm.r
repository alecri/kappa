plot.rma.glmm <- function(x, qqplot=FALSE, ...) {

   #########################################################################

   if (!inherits(x, "rma.glmm"))
      stop("Argument 'x' must be an object of class \"rma.glmm\".")

   stop("Method not yet implemented for objects of class \"rma.glmm\". Sorry!")

}
