addpoly <- function(x, ...)
   UseMethod("addpoly")
