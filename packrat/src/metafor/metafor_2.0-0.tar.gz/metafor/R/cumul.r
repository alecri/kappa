cumul <- function(x, ...)
   UseMethod("cumul")
