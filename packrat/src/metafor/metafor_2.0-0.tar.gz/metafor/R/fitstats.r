fitstats <- function (object, ...)
   UseMethod("fitstats")
