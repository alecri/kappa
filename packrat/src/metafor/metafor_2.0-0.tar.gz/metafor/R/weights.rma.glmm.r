weights.rma.glmm <- function(object, ...) {

   if (!inherits(object, "rma.glmm"))
      stop("Argument 'object' must be an object of class \"rma.glmm\".")

   stop("Method not yet implemented for objects of class \"rma.glmm\". Sorry!")

}
