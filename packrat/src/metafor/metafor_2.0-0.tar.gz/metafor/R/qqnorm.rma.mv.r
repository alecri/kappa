qqnorm.rma.mv <- function(y, ...) {

   if (!inherits(y, "rma.mv"))
      stop("Argument 'y' must be an object of class \"rma.mv\".")

   stop("Method not yet implemented for objects of class \"rma.mv\". Sorry!")

}
